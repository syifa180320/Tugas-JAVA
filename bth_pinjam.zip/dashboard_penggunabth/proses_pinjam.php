<?php 
session_start();
include '../koneksi.php';

$username = $_SESSION['username'];

$nama = $_POST['nama'];
$pj = $_POST['pj'];
$tgl_pinjam = $_POST['tgl_pinjam'];
$tgl_kembali = $_POST['tgl_kembali'];
$keperluan = $_POST['keperluan'];

$peralatan_id = implode(",", $_POST['peralatan_id']);

mysqli_query($conn,"INSERT INTO peminjaman 
VALUES(NULL,'$nama','$pj','$peralatan_id','$tgl_pinjam','$tgl_kembali','$keperluan','menunggu',NOW())");

/* Notifikasi untuk admin */

$pesan_admin = "Terdapat pengajuan peminjaman peralatan baru dari ".$nama.".";

mysqli_query($conn,"
INSERT INTO notifikasi(username,pesan,status)
VALUES('admin','$pesan_admin','belum_dibaca')
");

header("location:riwayat.php");

?>