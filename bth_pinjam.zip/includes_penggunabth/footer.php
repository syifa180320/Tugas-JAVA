<!-- Footer -->
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>
        copyright &copy;
        <script>document.write(new Date().getFullYear());</script>
        - developed by
        <b>
          <a href="https://www.instagram.com/dedesyifa_maspupah?igsh=ejM3eHpjeWQzbmc3" target="_blank">
            Dede Syifa Maspupah
          </a>
        </b>
      </span>
    </div>
  </div>
</footer>

<!-- Scroll to top -->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<!-- Audio Notifikasi -->
<audio id="notifSound">
  <source src="suara/notif.mp3" type="audio/mpeg">
</audio>

<!-- ===================== -->
<!-- JAVASCRIPT SECTION -->
<!-- ===================== -->

<!-- WAJIB: Load jQuery dulu -->
<script src="../assets/vendor/jquery/jquery.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../assets/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="../assets/js/ruang-admin.min.js"></script>
<script src="../assets/vendor/chart.js/Chart.min.js"></script>
<script src="../assets/js/demo/chart-area-demo.js"></script>

<script>
/* =======================
   NOTIFIKASI SYSTEM
======================= */

let lastCount = 0;

setInterval(function () {

  fetch('notifikasi.php')
    .then(res => res.json())
    .then(data => {

      if (!Array.isArray(data)) return;

      if (data.length > lastCount) {

        let pesan = data[0]?.pesan || 'Notifikasi baru';

        // suara
        const audio = document.getElementById('notifSound');
        if (audio) audio.play().catch(() => {});

        // popup
        alert(pesan);

        // toast custom
        showNotif(pesan);
      }

      lastCount = data.length;
    })
    .catch(err => console.log("Notif error:", err));

}, 5000);


/* klik notif (event delegation aman) */
document.addEventListener("click", function (e) {

  const item = e.target.closest(".notif-item");
  if (!item) return;

  e.preventDefault();

  let id = item.dataset.id;

  fetch("baca_notifikasi.php?id=" + id)
    .then(res => res.text())
    .then(res => {

      if (res.trim() === "ok") {

        item.classList.remove("notif-belum");
        item.classList.add("notif-sudah");

        let dot = item.querySelector(".notif-dot");
        if (dot) dot.remove();
      }

    });

});


function showNotif(pesan) {

  let notif = document.createElement("div");

  notif.textContent = pesan;

  Object.assign(notif.style, {
    position: "fixed",
    top: "20px",
    right: "20px",
    width: "300px",
    background: "#28a745",
    color: "#fff",
    padding: "12px",
    fontSize: "14px",
    borderRadius: "8px",
    zIndex: 99999,
    boxShadow: "0 0 10px rgba(0,0,0,.3)"
  });

  document.body.appendChild(notif);

  setTimeout(() => notif.remove(), 5000);
}


/* =======================
   DATA BOOKING (PHP → JS)
======================= */
</script>

<?php
$dataBooking = [];

$q = mysqli_query($conn, "
SELECT peralatan_id, tgl_pinjam, tgl_kembali
FROM peminjaman
WHERE LOWER(TRIM(status))='diterima'
");

while ($row = mysqli_fetch_assoc($q)) {
  $dataBooking[] = $row;
}
?>

<script>
const bookingData = <?= json_encode($dataBooking ?? [], JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>;
const totalAlat = <?= (int)($total_peralatan ?? 0); ?>;


/* =======================
   CALENDAR SYSTEM
======================= */

let currentDate = new Date(2026, 5, 1); // Juni 2026

function renderCalendar() {

  const monthYearEl = document.getElementById('month-year');
  const gridEl = document.getElementById('calendar-grid');

  if (!monthYearEl || !gridEl) return;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Ags","Sep","Okt","Nov","Des"];
  monthYearEl.textContent = `${monthNames[month]} ${year}`;

  gridEl.innerHTML = '';

  const hari = ['Min','Sen','Sel','Rab','Kam','Jum','Sab'];
  hari.forEach(h => {
    const el = document.createElement('div');
    el.className = 'calendar-day-name';
    el.textContent = h;
    gridEl.appendChild(el);
  });

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let i = 0; i < firstDay; i++) {
    const empty = document.createElement('div');
    empty.className = 'calendar-day empty';
    gridEl.appendChild(empty);
  }

  for (let i = 1; i <= daysInMonth; i++) {

    const dayEl = document.createElement('div');
    dayEl.className = 'calendar-day';
    dayEl.textContent = i;

    const tanggal = `${year}-${String(month + 1).padStart(2,'0')}-${String(i).padStart(2,'0')}`;

    let alatDipinjam = new Set();

    bookingData.forEach(item => {

      if (tanggal >= item.tgl_pinjam && tanggal <= item.tgl_kembali) {

        (item.peralatan_id || '').split(',').forEach(id => {
          if (id.trim()) alatDipinjam.add(id.trim());
        });

      }

    });

    let jumlah = alatDipinjam.size;

    if (jumlah > 0 && jumlah < totalAlat) {
      dayEl.style.background = "#007bff";
      dayEl.style.color = "#fff";
    } 
    else if (jumlah >= totalAlat) {
      dayEl.style.background = "#dc3545";
      dayEl.style.color = "#fff";
    }

    dayEl.onclick = () => pilihTanggal(tanggal);

    gridEl.appendChild(dayEl);
  }
}

function prevMonth() {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar();
}

function nextMonth() {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar();
}

function pilihTanggal(tanggal){

    document.getElementById('tgl_pinjam').value = tanggal;

    const tglKembali = new Date(tanggal);

    // Maksimal peminjaman 1 hari
    tglKembali.setDate(tglKembali.getDate() + 1);

    document.getElementById('tgl_kembali').value =
        tglKembali.toISOString().split('T')[0];

    cekPeralatan();

    $('#modalPinjam').modal('show');
}

document.addEventListener("DOMContentLoaded", function () {
  renderCalendar();
});


/* =======================
   CEK PERALATAN AJAX
======================= */

function cekPeralatan() {

  let tgl_pinjam = $('#tgl_pinjam').val();
  let tgl_kembali = $('#tgl_kembali').val();

  if (!tgl_pinjam || !tgl_kembali) return;

  $.ajax({
    url: 'cek_peralatan.php',
    type: 'POST',
    data: {
      tgl_pinjam: tgl_pinjam,
      tgl_kembali: tgl_kembali
    },
    success: function (res) {
      $('#daftarPeralatan').html(res);
    }
  });
}


/* =======================
   SEARCH TABLE
======================= */

document.addEventListener("DOMContentLoaded", function () {

  const input = document.getElementById("searchInput");
  const rows = document.querySelectorAll("#dataTable tr");

  if (!input) return;

  input.addEventListener("input", function () {

    let keyword = this.value.toLowerCase();

    rows.forEach(row => {
      row.style.display =
        row.innerText.toLowerCase().includes(keyword)
          ? ""
          : "none";
    });

  });

});
</script>

</body>
</html>