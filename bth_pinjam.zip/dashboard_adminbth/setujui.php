<?php
include "../koneksi.php";

$id = $_GET['id'];

$get = mysqli_query($conn,"
SELECT *
FROM peminjaman
WHERE peminjaman_id='$id'
");

$data = mysqli_fetch_assoc($get);

if (!$data) {
    die("Peminjaman tidak ditemukan");
}

$username = $data['nama'];

$update = mysqli_query($conn,"
UPDATE peminjaman
SET status='diterima'
WHERE peminjaman_id='$id'
");

if (!$update) {
    die("Gagal update peminjaman: " . mysqli_error($conn));
}

$pesan = "Pengajuan peminjaman Anda telah disetujui oleh Admin Laboratorium.";

$insert = mysqli_query($conn,"
INSERT INTO notifikasi
(username,pesan,status)
VALUES
('$username','$pesan','belum_dibaca')
");

if (!$insert) {
    die("Gagal insert notifikasi: " . mysqli_error($conn));
}

header("Location:index.php");
exit;