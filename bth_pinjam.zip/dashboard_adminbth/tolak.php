<?php

include "../koneksi.php";

$id = $_GET['id'];

$get = mysqli_query($conn,"
SELECT *
FROM peminjaman
WHERE peminjaman_id='$id'
");

$data = mysqli_fetch_assoc($get);

$username = $data['nama'];

mysqli_query($conn,"
UPDATE peminjaman
SET status='ditolak'
WHERE peminjaman_id='$id'
");

$pesan = "Pengajuan peminjaman Anda ditolak oleh Admin Laboratorium.";

mysqli_query($conn,"
INSERT INTO notifikasi
(username,pesan,status)
VALUES
('$username','$pesan','belum_dibaca')
");

header("Location:index.php");
exit;