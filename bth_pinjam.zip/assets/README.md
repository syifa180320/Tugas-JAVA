# RuangAdmin

RuangAdmin - Free Admin Control Panel Themes Based on Bootstrap 4

-------------------

**RuangAdmin** is responsive admin template. Based on Bootstrap 4 Framework. Highly customizable and easy to use. 

**You can review it on [RuangAdmin - Demo](https://indrijunanda.github.io/RuangAdmin/)**

!["RuangAdmin Screenshot"](https://indrijunanda.github.io/RuangAdmin/img/screenshot/ss2.png "RuangAdmin Screenshot")

## Contribution 

Here is how : 

- Fork the repository
- Clone with ```git clone https://github.com/indrijunanda/RuangAdmin.git```
- Or Download zip


## Integrated

- **[CodeIgniter](https://github.com/Codeigniter-Template/Ruang-Admin-Template)** by Codeigniter Template
- **[Laravel](https://github.com/putralangkat97/ruang-admin-laravel-6)** by putralangkat97
- **[Laravel Starter Kit](https://github.com/superXdev/QAdmin)** by superXdev


## License

RuangAdmin is an open source and licensed under **[MIT](http://opensource.org/licenses/MIT)**

---

### Donate
Want to buy me a Coffee ? 

**[Klik Here](https://trakteer.id/indrijunanda/tip)** Powered by Trakteer


---
### Cheers Up!

*Happy Developing and Learning* 💪



Regards 😁😁



