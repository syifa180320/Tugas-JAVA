<!-- Footer -->
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>
        copyright &copy;
        <script>document.write(new Date().getFullYear());</script>
        - developed by
        <b>
          <a href="https://www.instagram.com/dedesyifa_maspupah?igsh=ejM3eHpjeWQzbmc3" target="_blank">
            Dede Syifa Maspupah
          </a>
        </b>
      </span>
    </div>
  </div>
</footer>

<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<audio id="notifSound">
  <source src="suara/notif.mp3" type="audio/mpeg">
</audio>

<!-- ===================== -->
<!-- LOAD LIBRARY (WAJIB URUT) -->
<!-- ===================== -->
<script src="../assets/vendor/jquery/jquery.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../assets/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="../assets/js/ruang-admin.min.js"></script>
<script src="../assets/vendor/chart.js/Chart.min.js"></script>
<script src="../assets/js/demo/chart-area-demo.js"></script>

<?php
// =====================
// DATA PHP AMAN
// =====================

// total alat
$qTotal = mysqli_query($conn, "SELECT COUNT(*) as total FROM peralatan");
$dTotal = mysqli_fetch_assoc($qTotal);
$total_peralatan = (int)($dTotal['total'] ?? 0);

// booking (count per tanggal)
$booking = [];

$qBooking = mysqli_query($conn, "
    SELECT tgl_pinjam, COUNT(*) as jumlah
    FROM peminjaman
    WHERE status IN ('menunggu','diterima','ditolak')
    GROUP BY tgl_pinjam
");

while ($row = mysqli_fetch_assoc($qBooking)) {
    $booking[$row['tgl_pinjam']] = (int)$row['jumlah'];
}
?>

<script>
/* =====================
   SAFE DATA JS
===================== */
const bookingData = <?= json_encode($booking ?? [], JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>;
const totalAlat = <?= $total_peralatan ?>;

/* =====================
   NOTIFIKASI SYSTEM FIX
===================== */

let lastId = 0;

setInterval(() => {

  fetch('notifikasi.php')
    .then(r => r.json())
    .then(data => {

      if (!Array.isArray(data) || data.length === 0) return;

      const notif = data[0];

      if (!notif || notif.notifikasi_id == lastId) return;

      lastId = notif.notifikasi_id;

      const audio = document.getElementById('notifSound');
      if (audio) {
        audio.currentTime = 0;
        audio.play().catch(() => {});
      }

      showNotif(notif.pesan || 'Notifikasi baru');

      fetch('update_suara.php?id=' + notif.notifikasi_id)
        .catch(() => {});

    })
    .catch(() => {});

}, 5000);

/* klik notif */
document.addEventListener("click", function (e) {

  const item = e.target.closest(".notif-item");
  if (!item) return;

  e.preventDefault();

  fetch("baca_notifikasi.php?id=" + item.dataset.id)
    .then(r => r.text())
    .then(res => {

      if (res.trim() === "ok") {
        item.classList.add("notif-sudah");
        item.classList.remove("notif-belum");

        const dot = item.querySelector(".notif-dot");
        if (dot) dot.remove();
      }

    });

});

/* popup notif */
function showNotif(pesan) {

  const box = document.createElement("div");

  box.innerHTML = pesan;

  Object.assign(box.style, {
    position: "fixed",
    top: "20px",
    right: "20px",
    background: "#28a745",
    color: "#fff",
    padding: "12px 15px",
    borderRadius: "8px",
    zIndex: 99999,
    boxShadow: "0 5px 15px rgba(0,0,0,.3)",
    maxWidth: "300px"
  });

  document.body.appendChild(box);

  setTimeout(() => box.remove(), 4000);
}

/* =====================
   CALENDAR FIX FINAL
===================== */

let currentDate = new Date();

function renderCalendar() {

  const monthYear = document.getElementById('month-year');
  const grid = document.getElementById('calendar-grid');

  if (!monthYear || !grid) return;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const months = [
    "Januari","Februari","Maret","April","Mei","Juni",
    "Juli","Agustus","September","Oktober","November","Desember"
  ];

  monthYear.textContent = `${months[month]} ${year}`;

  grid.innerHTML = '';

  const days = ['Min','Sen','Sel','Rab','Kam','Jum','Sab'];

  days.forEach(d => {
    const el = document.createElement('div');
    el.className = 'calendar-day-name';
    el.textContent = d;
    grid.appendChild(el);
  });

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let i = 0; i < firstDay; i++) {
    const empty = document.createElement('div');
    empty.className = 'calendar-day empty';
    grid.appendChild(empty);
  }

  for (let i = 1; i <= daysInMonth; i++) {

    const dateStr =
      `${year}-${String(month+1).padStart(2,'0')}-${String(i).padStart(2,'0')}`;

    const dayEl = document.createElement('div');
    dayEl.className = 'calendar-day';
    dayEl.textContent = i;

    const jumlah = bookingData[dateStr] || 0;

    if (jumlah === 0) {
      dayEl.classList.add('available');
    }
    else if (jumlah < totalAlat) {
      dayEl.classList.add('partial-booking');
    }
    else {
      dayEl.classList.add('full-booking');
    }

    grid.appendChild(dayEl);
  }
}

function prevMonth() {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar();
}

function nextMonth() {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar();
}

document.addEventListener("DOMContentLoaded", renderCalendar);

/* =====================
   SEARCH TABLE FIX
===================== */

document.addEventListener("DOMContentLoaded", () => {

  const input = document.getElementById("searchInput");
  const rows = document.querySelectorAll("#dataTable tr");

  if (!input) return;

  input.addEventListener("input", function () {

    const keyword = this.value.toLowerCase();

    rows.forEach(row => {
      row.style.display =
        row.innerText.toLowerCase().includes(keyword) ? "" : "none";
    });

  });

});
</script>

</body>
</html>